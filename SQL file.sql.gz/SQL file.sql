-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 04, 2020 at 09:04 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clinic management system dbms`
--

-- --------------------------------------------------------

--
-- Table structure for table `check_up`
--

CREATE TABLE `check_up` (
  `check_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `complains` text DEFAULT NULL,
  `findings` text DEFAULT NULL,
  `treat_id` int(11) NOT NULL,
  `med_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `date_` date DEFAULT NULL,
  `equipment_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `check_up`
--

INSERT INTO `check_up` (`check_id`, `patient_id`, `complains`, `findings`, `treat_id`, `med_id`, `quantity`, `date_`, `equipment_id`) VALUES
(1, 102020001, 'Has a mild fever', 'corona positive', 1, 2, 10, '2020-04-15', 31);

-- --------------------------------------------------------

--
-- Table structure for table `equipments`
--

CREATE TABLE `equipments` (
  `equipment_id` int(11) NOT NULL,
  `equipment_name` varchar(64) NOT NULL,
  `requested_date` date DEFAULT NULL,
  `defected_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `equipments`
--

INSERT INTO `equipments` (`equipment_id`, `equipment_name`, `requested_date`, `defected_date`) VALUES
(12, 'Ventilator', '2020-03-31', '2020-10-31'),
(31, 'Whatever', '2019-12-10', '2020-10-08'),
(45, 'X_Ray Machine', '2020-02-01', '2020-06-27');

-- --------------------------------------------------------

--
-- Table structure for table `medicines`
--

CREATE TABLE `medicines` (
  `med_id` int(11) NOT NULL,
  `med_name` varchar(64) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `available_qty` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `expiry_data` date NOT NULL,
  `requested_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `medicines`
--

INSERT INTO `medicines` (`med_id`, `med_name`, `quantity`, `available_qty`, `description`, `expiry_data`, `requested_date`) VALUES
(2, 'sinarest', 10, 20, 'only if the doctor prescribes', '2020-05-15', '2020-04-07'),
(12, 'CROCIN', 0, 500, 'cold,headache', '2020-04-03', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `patient_id` int(11) NOT NULL,
  `Fname` varchar(64) NOT NULL,
  `Lname` varchar(64) NOT NULL,
  `patient_type` varchar(64) NOT NULL,
  `age` int(11) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`patient_id`, `Fname`, `Lname`, `patient_type`, `age`, `address`) VALUES
(102020001, 'Abhishek', 'Chachadi', 'Male', 44, 'Belagavi'),
(102020003, 'ABHISHEK', 'CHACHADI', '43', 23, 'C-112 , CAUVERY RVCE BOYS HOSTEL ,RVCE CAMPUS , MYSORE ROAD ,BENGALURU'),
(112018001, 'harish', 'Digambar', 'M', 19, 'Shivaji Nagar Bengaluru');

-- --------------------------------------------------------

--
-- Table structure for table `treatments`
--

CREATE TABLE `treatments` (
  `treat_id` int(11) NOT NULL,
  `treat_type` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `treatments`
--

INSERT INTO `treatments` (`treat_id`, `treat_type`) VALUES
(1, 'Corona_treatment'),
(3, 'Sonic_Check');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `check_up`
--
ALTER TABLE `check_up`
  ADD PRIMARY KEY (`check_id`),
  ADD KEY `patient_id` (`patient_id`),
  ADD KEY `treat_id` (`treat_id`),
  ADD KEY `med_id` (`med_id`),
  ADD KEY `equipment_id` (`equipment_id`);

--
-- Indexes for table `equipments`
--
ALTER TABLE `equipments`
  ADD PRIMARY KEY (`equipment_id`);

--
-- Indexes for table `medicines`
--
ALTER TABLE `medicines`
  ADD PRIMARY KEY (`med_id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`patient_id`);

--
-- Indexes for table `treatments`
--
ALTER TABLE `treatments`
  ADD PRIMARY KEY (`treat_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `check_up`
--
ALTER TABLE `check_up`
  ADD CONSTRAINT `check_up_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`),
  ADD CONSTRAINT `check_up_ibfk_2` FOREIGN KEY (`treat_id`) REFERENCES `treatments` (`treat_id`),
  ADD CONSTRAINT `check_up_ibfk_3` FOREIGN KEY (`med_id`) REFERENCES `medicines` (`med_id`),
  ADD CONSTRAINT `check_up_ibfk_4` FOREIGN KEY (`equipment_id`) REFERENCES `equipments` (`equipment_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
